# cse12-wi22-pa8-BinarySearchTree-Sorting-starter
Link to write-up
https://docs.google.com/document/d/1rA0qqdiU69TZq6EznUaQPUbUO9i5o8QA0XQvfsoyGPE/edit?usp=sharing