public class MyCalendar {
    MyTreeMap<Integer, Integer> calendar;
    
    public MyCalendar() {
        // TODO
    }
    
    public boolean book(int start, int end) {
        // TODO
        return false;
    }

    public MyTreeMap<Integer, Integer> getCalendar(){
        return this.calendar;
    }
}